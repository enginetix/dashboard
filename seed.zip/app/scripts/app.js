/**
 * INSPINIA - Responsive Admin Theme
 *
 */
(function () {
    angular.module('inspinia', [
        'ui.router',                    // Routing
        'ui.bootstrap',					// Bootstrap
        'oc.lazyLoad',	                // ocLazyload
        'rzModule'						// slider
    ])
})();